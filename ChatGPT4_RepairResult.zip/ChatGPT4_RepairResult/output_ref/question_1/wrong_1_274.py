'''
def search(x, seq):
    if not seq:
        return 0
    elif x > max(seq):
        return len(seq)
    else:
        for i in range(len(seq)):
            if seq[i] >= x:
                return i
    return len(seq)
'''