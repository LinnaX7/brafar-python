'''
def search(x, seq):
    for i, elem in enumerate(seq):
        if not seq:  # Check if seq is empty
            return 0
        elif x <= elem:  # Adjusted condition
            return i
    return len(seq)  # Return length if not found

'''
Reference correct code:
'''
def search(x, seq):
    for i in range(len(seq)):
        if x <= seq[i]:
            return i
    return len(seq)
'''