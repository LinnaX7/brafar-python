'''
def search(x, seq):
    if seq == []:  # simply compare seq to an empty list
        return 0
    for i in range(len(seq)):  # use range(len(seq)) to get the index
        if x <= seq[i]:  # compare with the element at index i
            return i
    return len(seq)  # return len(seq) if x is greater than all elements
'''