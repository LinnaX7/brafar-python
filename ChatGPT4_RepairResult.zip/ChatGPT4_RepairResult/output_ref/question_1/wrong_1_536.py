'''
def search(x, seq):
    if seq and x > max(seq):
        return len(seq)
    for i, number in enumerate(seq):
        if x <= number:
            return i
    return len(seq)
'''