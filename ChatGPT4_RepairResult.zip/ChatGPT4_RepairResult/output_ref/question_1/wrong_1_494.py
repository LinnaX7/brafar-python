'''
def search(x, seq):
    if seq == () or seq == []:
        return None
    else:
        for i, elem in enumerate(seq):
            if x <= elem:
                return i
        return len(seq)
'''
