Here's the repaired version of your code:

'''
def search(x, seq):
    if seq == ():
        return 'not found'
    for i, elem in enumerate(seq):
        if x <= elem:
            return i
    return len(seq)
'''