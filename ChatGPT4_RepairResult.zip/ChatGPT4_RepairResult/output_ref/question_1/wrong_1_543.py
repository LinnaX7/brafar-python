Here's the repaired code:

```
def search(x, seq):
    if len(seq) == 0:
        return 0
    else:
        if x < seq[0]:
            return 0
        elif x > seq[-1]:
            return len(seq)
        else:
            for i in range(len(seq)):
                if x <= seq[i]:
                    return i
```

The modifications include fixing the indentation and return statements to correctly match the logic of the reference correct code.