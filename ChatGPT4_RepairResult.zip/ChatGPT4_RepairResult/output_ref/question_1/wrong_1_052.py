```
def search(x, seq):
    if seq == () or seq == []:
        return 0
    
    newseq = list(seq)
    
    if newseq[-1] < x:
        return len(newseq)
    
    for pos, elem in enumerate(newseq):
        if x <= elem:
            return pos
    return len(newseq)
```