'''
def search(x, seq):
    n = len(seq)
    for i in range(0,n):
        if x <= seq[i]:
            return i
    return n
'''
