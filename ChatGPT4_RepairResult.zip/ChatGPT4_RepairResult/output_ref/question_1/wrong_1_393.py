```
def search(x, seq):
    if type(seq) == tuple:
        seq = list(seq)
    for i in range(len(seq)):
        if x <= seq[i]:
            return i
    return len(seq)
```