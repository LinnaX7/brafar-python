'''
def search(x, seq):
    n = len(seq)
    for counter in range(n):
        if seq[counter] >= x:
            return counter
    return n
'''
