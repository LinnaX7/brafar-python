'''
def search(x, seq):
    if not seq:  # Handles both empty tuple and empty list
        return 0
    for i, elem in enumerate(seq):
        if x <= elem:
            return i
    return len(seq)  # Moved out of the for loop
'''