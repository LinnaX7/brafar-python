Here's the corrected version of the provided code:
```
def search(x, seq):
    for i, elem in enumerate(seq):
        if x <= elem:
            return i
    return len(seq)
```