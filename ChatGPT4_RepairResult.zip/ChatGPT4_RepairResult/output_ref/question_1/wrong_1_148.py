'''
def search(val,seq):
    if val <= seq[0]:
        position = 0
    elif val >= seq[-1]:
        position = len(seq)
    else:
        for i in range(len(seq)):
            if val <= seq[i]:
                position = i
                break
    return position
'''