'''
def search(x, seq):
    for i, element in enumerate(seq):
        if seq == ():
            return 0
        else:
            if x <= element:
                return i
    return len(seq)
'''
