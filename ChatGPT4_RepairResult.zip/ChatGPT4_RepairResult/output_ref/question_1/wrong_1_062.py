```
def search(x, seq):
    if type(seq) == tuple:
        seq = list(seq)
    seq.append(x)
    seq = sorted(seq)
    return seq.index(x)
```