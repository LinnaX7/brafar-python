'''
def search(x, seq):
    if len(seq) == 0:
        return 0
    for i, elem in enumerate(seq):
        if x < elem:
            return i
        elif i == len(seq) - 1:
            return len(seq)
'''