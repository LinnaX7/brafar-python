'''
def search(x, seq):
    a = list(enumerate(seq))
    seq = list(seq)
    i = 0
    while i < len(seq):
        if seq == []:
            return 0
        if x < seq[i] and i == 0:
            return 0
        elif x <= seq[i] and (i == 0 or x > seq[i-1]):
            return i
        elif x > seq[len(seq)-1]:
            return len(seq)
        else:
            i = i + 1
            
    return i
'''