Here is the repaired code with minimal modifications:

```
def search(x, seq):
    for i in range(len(seq)):
        if seq[i] is None:
            return 0
        elif x <= seq[i]:
            return i
    return len(seq)
```