Here is the repaired code, with modifications made to match the logic of the reference code:

```
def search(x, seq):
    for i in range(len(seq)):
        if x <= seq[i]:
            return i
    return len(seq)
```