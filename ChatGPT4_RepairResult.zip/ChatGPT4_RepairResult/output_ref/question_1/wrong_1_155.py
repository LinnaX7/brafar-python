'''
def search(x, seq):
    if seq==[]:
        return 0
    for a, b in enumerate(seq):
        if x <= b:
            return a
    return len(seq)
'''