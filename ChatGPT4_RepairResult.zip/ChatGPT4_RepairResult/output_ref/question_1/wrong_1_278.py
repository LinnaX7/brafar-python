'''
def search(x, seq):
    if not seq or x > seq[-1]:  # Check if the sequence is empty or x is greater than the last element
        return len(seq)
    else:
        for i in range(len(seq)):  # Use range(len(seq)) instead of enumerate for this case
            if x <= seq[i]:
                return i
'''