'''
def search(x, seq):
    if not seq:
        return 0
    for c, value in enumerate(seq):
        if x <= value:
            return c
    return len(seq)
'''