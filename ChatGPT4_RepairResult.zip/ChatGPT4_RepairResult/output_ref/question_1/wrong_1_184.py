'''
def search(x, seq):
    for i in range(len(seq)):
        if x>i:
            continue
        else:
            return i
    return len(seq)
'''