```python
def search(val, seq):
    for i in range(len(seq)):
        if val <= seq[i]:
            return i
    return len(seq)
```