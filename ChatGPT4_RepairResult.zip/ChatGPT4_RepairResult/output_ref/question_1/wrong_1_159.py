Below is the repaired code with minimal modifications based on the reference provided:
```
def search(x, seq):
    if not seq or x <= seq[0]:
        return 0
    for i in range(1, len(seq)):
        if x <= seq[i]:
            return i
    return len(seq)
```