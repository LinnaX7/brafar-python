'''
def search(x, seq):
    position = 0
    while position < len(seq):
        if x <= seq[position]:
            return position
        else:
            position += 1
    return len(seq)
'''