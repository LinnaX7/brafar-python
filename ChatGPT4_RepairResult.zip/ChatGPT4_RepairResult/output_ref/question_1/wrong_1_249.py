Here is the repaired code:

```
def search(x, seq):
    if seq and x <= seq[0]:
        return 0
    for i in range(1, len(seq)):
        if x <= seq[i]:
            return i
    return len(seq)
```