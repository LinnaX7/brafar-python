```
def search(x, seq):
    if seq == ():  # Check if the sequence is empty first
        return 0
    elif x < seq[0]:  # If x is less than the first element
        return 0
    elif x > seq[-1]:  # If x is greater than the last element
        return len(seq)
    else:
        for i in range(len(seq)):  # Iterate through the sequence
            if x <= seq[i]:  # If x is less than or equal to the current element
                return i
    return len(seq)  # If x is not found, return the length of the sequence
```