'''
def search(x, seq):
    if not seq:  # Checking if seq is empty
        return -1
    for i, elem in enumerate(seq):
        if x <= elem:
            return i
    return len(seq)
'''
