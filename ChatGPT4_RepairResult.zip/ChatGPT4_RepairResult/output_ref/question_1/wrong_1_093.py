'''
def search(x, seq):
    if seq:  # Check if the sequence is not empty
        for i in range(len(seq)):
            if x <= seq[i]:
                return i
    return len(seq)
'''